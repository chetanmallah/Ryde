import React, { useState } from 'react';
import { Gamepad2, ArrowLeft } from 'lucide-react';
import { Link } from 'react-router-dom';
import { SnakeGame } from './games/SnakeGame';
import { MemoryGame } from './games/MemoryGame';
import { TicTacToe } from './games/TicTacToe';

export const Game = () => {
  const [selectedGame, setSelectedGame] = useState<string | null>(null);

  const games = [
    {
      id: 'snake',
      title: 'Snake Game',
      description: 'Classic snake game - eat food to grow longer!',
      component: SnakeGame,
    },
    {
      id: 'memory',
      title: 'Memory Card Game',
      description: 'Test your memory by matching pairs of cards',
      component: MemoryGame,
    },
    {
      id: 'tictactoe',
      title: 'Tic Tac Toe',
      description: 'Classic X and O game - challenge yourself!',
      component: TicTacToe,
    },
  ];

  const SelectedGameComponent = selectedGame 
    ? games.find(game => game.id === selectedGame)?.component 
    : null;

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <div className="flex items-center justify-between mb-8">
        <div className="flex items-center">
          <Gamepad2 className="h-8 w-8 text-indigo-600 mr-2" />
          <h1 className="text-3xl font-bold text-gray-900">Study Break Games</h1>
        </div>
        <Link
          to="/"
          className="flex items-center text-gray-600 hover:text-indigo-600"
        >
          <ArrowLeft className="h-5 w-5 mr-2" />
          Back to Home
        </Link>
      </div>

      {!selectedGame ? (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {games.map((game) => (
            <div
              key={game.id}
              onClick={() => setSelectedGame(game.id)}
              className="bg-white rounded-xl shadow-lg p-6 cursor-pointer transform hover:scale-105 transition-all duration-200"
            >
              <h2 className="text-xl font-semibold text-gray-900 mb-2">{game.title}</h2>
              <p className="text-gray-600 mb-4">{game.description}</p>
              <button className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors">
                Play Now
              </button>
            </div>
          ))}
        </div>
      ) : (
        <div className="bg-white rounded-xl shadow-lg p-6">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-semibold text-gray-900">
              {games.find(game => game.id === selectedGame)?.title}
            </h2>
            <button
              onClick={() => setSelectedGame(null)}
              className="flex items-center text-gray-600 hover:text-indigo-600"
            >
              <ArrowLeft className="h-5 w-5 mr-2" />
              Back to Games
            </button>
          </div>
          {SelectedGameComponent && <SelectedGameComponent />}
        </div>
      )}
    </div>
  );
};