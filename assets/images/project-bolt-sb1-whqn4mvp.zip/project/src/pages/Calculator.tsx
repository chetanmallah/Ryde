import React, { useState } from 'react';
import { Calculator as CalcIcon } from 'lucide-react';

export const Calculator = () => {
  const [display, setDisplay] = useState('0');
  const [equation, setEquation] = useState('');
  const [prevAnswer, setPrevAnswer] = useState('');

  const handleNumber = (num: string) => {
    setDisplay(display === '0' ? num : display + num);
    setEquation(equation + num);
  };

  const handleOperator = (op: string) => {
    setDisplay('0');
    setEquation(equation + ' ' + op + ' ');
  };

  const handleEqual = () => {
    try {
      // eslint-disable-next-line no-eval
      const result = eval(equation);
      setDisplay(result.toString());
      setPrevAnswer(result.toString());
      setEquation('');
    } catch (error) {
      setDisplay('Error');
      setEquation('');
    }
  };

  const handleClear = () => {
    setDisplay('0');
    setEquation('');
  };

  const buttons = [
    ['7', '8', '9', '/'],
    ['4', '5', '6', '*'],
    ['1', '2', '3', '-'],
    ['0', '.', '=', '+'],
    ['C', 'sin', 'cos', 'tan'],
  ];

  return (
    <div className="max-w-md mx-auto px-4 py-8">
      <div className="bg-white rounded-xl shadow-lg p-6">
        <div className="flex items-center justify-center mb-6">
          <CalcIcon className="h-8 w-8 text-indigo-600 mr-2" />
          <h1 className="text-2xl font-bold text-gray-900">Scientific Calculator</h1>
        </div>

        <div className="bg-gray-100 p-4 rounded-lg mb-4">
          <div className="text-sm text-gray-600 mb-1">{equation || '\u00A0'}</div>
          <div className="text-3xl font-mono text-right">{display}</div>
          {prevAnswer && (
            <div className="text-sm text-gray-500 text-right">Ans = {prevAnswer}</div>
          )}
        </div>

        <div className="grid grid-cols-4 gap-2">
          {buttons.map((row, i) =>
            row.map((btn, j) => (
              <button
                key={`${i}-${j}`}
                onClick={() => {
                  if (btn === 'C') handleClear();
                  else if (btn === '=') handleEqual();
                  else if (['+', '-', '*', '/'].includes(btn)) handleOperator(btn);
                  else if (['sin', 'cos', 'tan'].includes(btn)) {
                    handleOperator(`Math.${btn}`);
                  }
                  else handleNumber(btn);
                }}
                className={`p-3 text-lg rounded-lg transition-colors ${
                  btn === '=' 
                    ? 'bg-indigo-600 text-white hover:bg-indigo-700'
                    : btn === 'C'
                    ? 'bg-red-100 text-red-600 hover:bg-red-200'
                    : ['sin', 'cos', 'tan'].includes(btn)
                    ? 'bg-purple-100 text-purple-600 hover:bg-purple-200'
                    : ['+', '-', '*', '/'].includes(btn)
                    ? 'bg-yellow-100 text-yellow-600 hover:bg-yellow-200'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                {btn}
              </button>
            ))
          )}
        </div>
      </div>
    </div>
  );
};