import React, { useState } from 'react';
import { Book, Search, Download, ExternalLink, ArrowLeft } from 'lucide-react';
import { Link } from 'react-router-dom';

interface Resource {
  id: number;
  title: string;
  description: string;
  subject: string;
  type: string;
  downloadUrl: string;
  fileSize: string;
}

const resources: Resource[] = [
  {
    id: 1,
    title: 'Advanced Mathematics Study Guide',
    description: 'Comprehensive guide covering calculus, algebra, and trigonometry',
    subject: 'Mathematics',
    type: 'PDF',
    downloadUrl: '#',
    fileSize: '2.5 MB'
  },
  {
    id: 2,
    title: 'Physics Formula Sheet',
    description: 'Complete collection of physics formulas for high school and college',
    subject: 'Physics',
    type: 'PDF',
    downloadUrl: '#',
    fileSize: '1.2 MB'
  },
  {
    id: 3,
    title: 'Chemistry Lab Manual',
    description: 'Detailed guide for common chemistry experiments and procedures',
    subject: 'Chemistry',
    type: 'PDF',
    downloadUrl: '#',
    fileSize: '3.1 MB'
  },
  {
    id: 4,
    title: 'Biology Study Notes',
    description: 'Organized notes covering major biology concepts and theories',
    subject: 'Biology',
    type: 'PDF',
    downloadUrl: '#',
    fileSize: '4.5 MB'
  },
  {
    id: 5,
    title: 'Computer Science Fundamentals',
    description: 'Essential concepts in programming and computer science',
    subject: 'Computer Science',
    type: 'PDF',
    downloadUrl: '#',
    fileSize: '2.8 MB'
  }
];

export const Resources = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedSubject, setSelectedSubject] = useState<string>('');

  const subjects = Array.from(new Set(resources.map(r => r.subject)));

  const filteredResources = resources.filter(resource => {
    const matchesSearch = resource.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         resource.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesSubject = !selectedSubject || resource.subject === selectedSubject;
    return matchesSearch && matchesSubject;
  });

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center">
            <Book className="h-8 w-8 text-indigo-600 mr-3" />
            <h1 className="text-3xl font-bold text-gray-900">Study Resources</h1>
          </div>
          <Link
            to="/"
            className="flex items-center text-gray-600 hover:text-indigo-600"
          >
            <ArrowLeft className="h-5 w-5 mr-2" />
            Back to Home
          </Link>
        </div>

        <div className="mb-8 grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
            <input
              type="text"
              placeholder="Search resources..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
            />
          </div>
          <select
            value={selectedSubject}
            onChange={(e) => setSelectedSubject(e.target.value)}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
          >
            <option value="">All Subjects</option>
            {subjects.map(subject => (
              <option key={subject} value={subject}>{subject}</option>
            ))}
          </select>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredResources.map((resource) => (
            <div
              key={resource.id}
              className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow"
            >
              <div className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-indigo-100 text-indigo-800">
                    {resource.subject}
                  </span>
                  <span className="text-sm text-gray-500">{resource.type}</span>
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">{resource.title}</h3>
                <p className="text-sm text-gray-600 mb-4">{resource.description}</p>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-500">{resource.fileSize}</span>
                  <div className="flex space-x-2">
                    <button
                      className="flex items-center space-x-1 px-3 py-1 bg-indigo-100 text-indigo-700 rounded-md hover:bg-indigo-200 transition-colors"
                      onClick={() => window.open(resource.downloadUrl, '_blank')}
                    >
                      <Download className="h-4 w-4" />
                      <span>Download</span>
                    </button>
                    <button
                      className="flex items-center space-x-1 px-3 py-1 bg-gray-100 text-gray-700 rounded-md hover:bg-gray-200 transition-colors"
                      onClick={() => window.open(resource.downloadUrl, '_blank')}
                    >
                      <ExternalLink className="h-4 w-4" />
                      <span>Preview</span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {filteredResources.length === 0 && (
          <div className="text-center py-12">
            <Book className="mx-auto h-12 w-12 text-gray-400" />
            <h3 className="mt-2 text-sm font-medium text-gray-900">No resources found</h3>
            <p className="mt-1 text-sm text-gray-500">
              Try adjusting your search terms or filters
            </p>
          </div>
        )}
      </div>
    </div>
  );
};