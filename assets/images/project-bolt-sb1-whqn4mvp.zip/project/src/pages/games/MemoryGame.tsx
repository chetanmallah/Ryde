import React, { useState, useEffect } from 'react';

const CARD_PAIRS = [
  { id: 1, emoji: '🎓' },
  { id: 2, emoji: '📚' },
  { id: 3, emoji: '✏️' },
  { id: 4, emoji: '📝' },
  { id: 5, emoji: '🎨' },
  { id: 6, emoji: '🔬' },
  { id: 7, emoji: '🧮' },
  { id: 8, emoji: '🌍' },
];

interface Card {
  id: number;
  emoji: string;
  isFlipped: boolean;
  isMatched: boolean;
}

export const MemoryGame = () => {
  const [cards, setCards] = useState<Card[]>([]);
  const [flippedCards, setFlippedCards] = useState<number[]>([]);
  const [moves, setMoves] = useState(0);
  const [gameOver, setGameOver] = useState(false);

  const initializeGame = () => {
    const duplicatedCards = [...CARD_PAIRS, ...CARD_PAIRS].map((card, index) => ({
      ...card,
      uniqueId: index,
      isFlipped: false,
      isMatched: false,
    }));

    // Shuffle cards
    const shuffledCards = duplicatedCards.sort(() => Math.random() - 0.5);
    setCards(shuffledCards);
    setFlippedCards([]);
    setMoves(0);
    setGameOver(false);
  };

  useEffect(() => {
    initializeGame();
  }, []);

  const handleCardClick = (index: number) => {
    if (
      flippedCards.length === 2 ||
      cards[index].isFlipped ||
      cards[index].isMatched
    ) {
      return;
    }

    const newCards = [...cards];
    newCards[index].isFlipped = true;
    setCards(newCards);

    const newFlippedCards = [...flippedCards, index];
    setFlippedCards(newFlippedCards);

    if (newFlippedCards.length === 2) {
      setMoves(moves + 1);
      const [firstIndex, secondIndex] = newFlippedCards;
      
      if (cards[firstIndex].id === cards[secondIndex].id) {
        // Match found
        setTimeout(() => {
          const matchedCards = [...cards];
          matchedCards[firstIndex].isMatched = true;
          matchedCards[secondIndex].isMatched = true;
          setCards(matchedCards);
          setFlippedCards([]);

          // Check if game is over
          if (matchedCards.every(card => card.isMatched)) {
            setGameOver(true);
          }
        }, 500);
      } else {
        // No match
        setTimeout(() => {
          const resetCards = [...cards];
          resetCards[firstIndex].isFlipped = false;
          resetCards[secondIndex].isFlipped = false;
          setCards(resetCards);
          setFlippedCards([]);
        }, 1000);
      }
    }
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-4">
        <p className="text-lg font-semibold">Moves: {moves}</p>
        <button
          onClick={initializeGame}
          className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors"
        >
          {gameOver ? 'Play Again' : 'Reset'}
        </button>
      </div>

      {gameOver && (
        <div className="text-center mb-4 p-4 bg-green-100 text-green-800 rounded-lg">
          <h2 className="text-xl font-bold">Congratulations! 🎉</h2>
          <p>You completed the game in {moves} moves!</p>
        </div>
      )}

      <div className="grid grid-cols-4 gap-4">
        {cards.map((card, index) => (
          <button
            key={index}
            onClick={() => handleCardClick(index)}
            className={`aspect-square text-4xl flex items-center justify-center rounded-lg transition-all duration-300 transform ${
              card.isFlipped || card.isMatched
                ? 'bg-white rotate-0'
                : 'bg-indigo-600 rotate-180'
            } ${
              card.isMatched ? 'bg-green-100' : ''
            } hover:scale-105`}
            disabled={card.isMatched}
          >
            {(card.isFlipped || card.isMatched) && card.emoji}
          </button>
        ))}
      </div>
    </div>
  );
};