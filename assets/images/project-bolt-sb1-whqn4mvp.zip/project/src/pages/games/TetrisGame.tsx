import React, { useState, useEffect, useCallback } from 'react';

const BOARD_WIDTH = 10;
const BOARD_HEIGHT = 20;
const TETROMINOS = {
  I: { shape: [[1, 1, 1, 1]], color: 'bg-cyan-500' },
  O: { shape: [[1, 1], [1, 1]], color: 'bg-yellow-500' },
  T: { shape: [[0, 1, 0], [1, 1, 1]], color: 'bg-purple-500' },
  L: { shape: [[1, 0], [1, 0], [1, 1]], color: 'bg-orange-500' },
};

export const TetrisGame = () => {
  const [board, setBoard] = useState(createEmptyBoard());
  const [score, setScore] = useState(0);
  const [gameOver, setGameOver] = useState(false);
  const [currentPiece, setCurrentPiece] = useState(getRandomPiece());
  const [position, setPosition] = useState({ x: 4, y: 0 });

  function createEmptyBoard() {
    return Array(BOARD_HEIGHT).fill(null).map(() => 
      Array(BOARD_WIDTH).fill(null)
    );
  }

  function getRandomPiece() {
    const pieces = Object.keys(TETROMINOS);
    const randomPiece = pieces[Math.floor(Math.random() * pieces.length)];
    return {
      shape: TETROMINOS[randomPiece as keyof typeof TETROMINOS].shape,
      color: TETROMINOS[randomPiece as keyof typeof TETROMINOS].color,
    };
  }

  const moveLeft = useCallback(() => {
    if (!isColliding(position.x - 1, position.y)) {
      setPosition(prev => ({ ...prev, x: prev.x - 1 }));
    }
  }, [position]);

  const moveRight = useCallback(() => {
    if (!isColliding(position.x + 1, position.y)) {
      setPosition(prev => ({ ...prev, x: prev.x + 1 }));
    }
  }, [position]);

  const moveDown = useCallback(() => {
    if (!isColliding(position.x, position.y + 1)) {
      setPosition(prev => ({ ...prev, y: prev.y + 1 }));
    } else {
      placePiece();
    }
  }, [position]);

  function isColliding(newX: number, newY: number) {
    for (let y = 0; y < currentPiece.shape.length; y++) {
      for (let x = 0; x < currentPiece.shape[y].length; x++) {
        if (currentPiece.shape[y][x]) {
          const boardX = newX + x;
          const boardY = newY + y;

          if (
            boardX < 0 ||
            boardX >= BOARD_WIDTH ||
            boardY >= BOARD_HEIGHT ||
            (boardY >= 0 && board[boardY][boardX])
          ) {
            return true;
          }
        }
      }
    }
    return false;
  }

  function placePiece() {
    const newBoard = [...board];
    for (let y = 0; y < currentPiece.shape.length; y++) {
      for (let x = 0; x < currentPiece.shape[y].length; x++) {
        if (currentPiece.shape[y][x]) {
          const boardY = position.y + y;
          const boardX = position.x + x;
          if (boardY < 0) {
            setGameOver(true);
            return;
          }
          newBoard[boardY][boardX] = currentPiece.color;
        }
      }
    }
    setBoard(newBoard);
    setCurrentPiece(getRandomPiece());
    setPosition({ x: 4, y: 0 });
    checkLines(newBoard);
  }

  function checkLines(board: string[][]) {
    let linesCleared = 0;
    const newBoard = board.filter(row => {
      const isComplete = row.every(cell => cell !== null);
      if (isComplete) linesCleared++;
      return !isComplete;
    });

    while (newBoard.length < BOARD_HEIGHT) {
      newBoard.unshift(Array(BOARD_WIDTH).fill(null));
    }

    if (linesCleared > 0) {
      setScore(prev => prev + (linesCleared * 100));
      setBoard(newBoard);
    }
  }

  useEffect(() => {
    if (gameOver) return;

    const handleKeyPress = (e: KeyboardEvent) => {
      switch (e.key) {
        case 'ArrowLeft':
          moveLeft();
          break;
        case 'ArrowRight':
          moveRight();
          break;
        case 'ArrowDown':
          moveDown();
          break;
        default:
          break;
      }
    };

    document.addEventListener('keydown', handleKeyPress);
    const gameInterval = setInterval(moveDown, 1000);

    return () => {
      document.removeEventListener('keydown', handleKeyPress);
      clearInterval(gameInterval);
    };
  }, [gameOver, moveDown, moveLeft, moveRight]);

  const resetGame = () => {
    setBoard(createEmptyBoard());
    setScore(0);
    setGameOver(false);
    setCurrentPiece(getRandomPiece());
    setPosition({ x: 4, y: 0 });
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-4">
        <p className="text-lg font-semibold">Score: {score}</p>
        <button
          onClick={resetGame}
          className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors"
        >
          {gameOver ? 'Play Again' : 'Reset'}
        </button>
      </div>

      <div className="relative bg-gray-100 w-full aspect-[1/2] rounded-lg overflow-hidden">
        {gameOver && (
          <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center">
            <div className="text-center text-white">
              <h2 className="text-3xl font-bold mb-4">Game Over!</h2>
              <p className="text-xl mb-4">Final Score: {score}</p>
              <button
                onClick={resetGame}
                className="px-6 py-3 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors"
              >
                Play Again
              </button>
            </div>
          </div>
        )}

        <div className="grid grid-cols-10 gap-px bg-gray-200 h-full">
          {board.map((row, y) => 
            row.map((cell, x) => {
              let isCurrent = false;
              let color = cell;

              if (currentPiece && !gameOver) {
                currentPiece.shape.forEach((row, pieceY) => {
                  row.forEach((value, pieceX) => {
                    if (
                      value &&
                      x === position.x + pieceX &&
                      y === position.y + pieceY
                    ) {
                      isCurrent = true;
                      color = currentPiece.color;
                    }
                  });
                });
              }

              return (
                <div
                  key={`${y}-${x}`}
                  className={`aspect-square ${
                    color || (isCurrent ? color : 'bg-gray-100')
                  }`}
                />
              );
            })
          )}
        </div>
      </div>

      <div className="mt-4 text-center text-gray-600">
        Use arrow keys to move: ← → ↓
      </div>
    </div>
  );
};