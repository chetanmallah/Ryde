import React, { useState } from 'react';

type Player = 'X' | 'O';
type Board = (Player | null)[];

const WINNING_COMBINATIONS = [
  [0, 1, 2], [3, 4, 5], [6, 7, 8], // Rows
  [0, 3, 6], [1, 4, 7], [2, 5, 8], // Columns
  [0, 4, 8], [2, 4, 6], // Diagonals
];

export const TicTacToe = () => {
  const [board, setBoard] = useState<Board>(Array(9).fill(null));
  const [currentPlayer, setCurrentPlayer] = useState<Player>('X');
  const [winner, setWinner] = useState<Player | 'Draw' | null>(null);

  const checkWinner = (squares: Board): Player | 'Draw' | null => {
    for (const combo of WINNING_COMBINATIONS) {
      const [a, b, c] = combo;
      if (
        squares[a] &&
        squares[a] === squares[b] &&
        squares[a] === squares[c]
      ) {
        return squares[a] as Player;
      }
    }

    if (squares.every(square => square !== null)) {
      return 'Draw';
    }

    return null;
  };

  const handleClick = (index: number) => {
    if (board[index] || winner) return;

    const newBoard = [...board];
    newBoard[index] = currentPlayer;
    setBoard(newBoard);

    const gameWinner = checkWinner(newBoard);
    if (gameWinner) {
      setWinner(gameWinner);
    } else {
      setCurrentPlayer(currentPlayer === 'X' ? 'O' : 'X');
    }
  };

  const resetGame = () => {
    setBoard(Array(9).fill(null));
    setCurrentPlayer('X');
    setWinner(null);
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-4">
        <p className="text-lg font-semibold">
          {winner
            ? winner === 'Draw'
              ? "It's a Draw!"
              : `Winner: ${winner}`
            : `Current Player: ${currentPlayer}`}
        </p>
        <button
          onClick={resetGame}
          className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors"
        >
          New Game
        </button>
      </div>

      <div className="grid grid-cols-3 gap-2 max-w-md mx-auto">
        {board.map((value, index) => (
          <button
            key={index}
            onClick={() => handleClick(index)}
            className={`aspect-square text-4xl font-bold flex items-center justify-center border-2 border-gray-200 ${
              value ? 'bg-white' : 'hover:bg-gray-50'
            } ${winner ? 'cursor-not-allowed' : 'cursor-pointer'}`}
            disabled={!!winner}
          >
            <span className={value === 'X' ? 'text-blue-600' : 'text-red-600'}>
              {value}
            </span>
          </button>
        ))}
      </div>

      {winner && (
        <div className="mt-4 text-center">
          {winner === 'Draw' ? (
            <p className="text-gray-600">Game ended in a draw!</p>
          ) : (
            <p className="text-green-600 font-semibold">
              Congratulations Player {winner}!
            </p>
          )}
        </div>
      )}
    </div>
  );
};