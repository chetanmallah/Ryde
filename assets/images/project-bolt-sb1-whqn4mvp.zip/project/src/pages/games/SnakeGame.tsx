import React, { useState, useEffect, useCallback } from 'react';

export const SnakeGame = () => {
  const [score, setScore] = useState(0);
  const [gameOver, setGameOver] = useState(false);
  const [snake, setSnake] = useState([{ x: 10, y: 10 }]);
  const [food, setFood] = useState({ x: 5, y: 5 });
  const [direction, setDirection] = useState('RIGHT');
  const [speed] = useState(150);

  const getRandomPosition = () => ({
    x: Math.floor(Math.random() * 20),
    y: Math.floor(Math.random() * 20),
  });

  const resetGame = () => {
    setSnake([{ x: 10, y: 10 }]);
    setFood(getRandomPosition());
    setDirection('RIGHT');
    setScore(0);
    setGameOver(false);
  };

  const moveSnake = useCallback(() => {
    if (gameOver) return;

    setSnake((prevSnake) => {
      const newSnake = [...prevSnake];
      const head = { ...newSnake[0] };

      switch (direction) {
        case 'UP':
          head.y -= 1;
          break;
        case 'DOWN':
          head.y += 1;
          break;
        case 'LEFT':
          head.x -= 1;
          break;
        case 'RIGHT':
          head.x += 1;
          break;
        default:
          break;
      }

      if (head.x < 0 || head.x >= 20 || head.y < 0 || head.y >= 20) {
        setGameOver(true);
        return prevSnake;
      }

      if (newSnake.some(segment => segment.x === head.x && segment.y === head.y)) {
        setGameOver(true);
        return prevSnake;
      }

      newSnake.unshift(head);

      if (head.x === food.x && head.y === food.y) {
        setScore(prev => prev + 1);
        setFood(getRandomPosition());
      } else {
        newSnake.pop();
      }

      return newSnake;
    });
  }, [direction, food, gameOver]);

  useEffect(() => {
    const handleKeyPress = (e: KeyboardEvent) => {
      switch (e.key) {
        case 'ArrowUp':
          setDirection(prev => prev !== 'DOWN' ? 'UP' : prev);
          break;
        case 'ArrowDown':
          setDirection(prev => prev !== 'UP' ? 'DOWN' : prev);
          break;
        case 'ArrowLeft':
          setDirection(prev => prev !== 'RIGHT' ? 'LEFT' : prev);
          break;
        case 'ArrowRight':
          setDirection(prev => prev !== 'LEFT' ? 'RIGHT' : prev);
          break;
        default:
          break;
      }
    };

    document.addEventListener('keydown', handleKeyPress);
    const gameInterval = setInterval(moveSnake, speed);

    return () => {
      document.removeEventListener('keydown', handleKeyPress);
      clearInterval(gameInterval);
    };
  }, [moveSnake, speed]);

  return (
    <div>
      <div className="flex justify-between items-center mb-4">
        <p className="text-lg font-semibold">Score: {score}</p>
        <button
          onClick={resetGame}
          className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors"
        >
          {gameOver ? 'Play Again' : 'Reset'}
        </button>
      </div>

      <div className="relative bg-gray-100 aspect-square rounded-lg overflow-hidden">
        {gameOver && (
          <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center">
            <div className="text-center text-white">
              <h2 className="text-3xl font-bold mb-4">Game Over!</h2>
              <p className="text-xl mb-4">Final Score: {score}</p>
              <button
                onClick={resetGame}
                className="px-6 py-3 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors"
              >
                Play Again
              </button>
            </div>
          </div>
        )}
        <div
          className="relative w-full h-full"
          style={{ background: 'repeating-linear-gradient(#f3f4f6 0 24px, #e5e7eb 25px 50px)' }}
        >
          {snake.map((segment, index) => (
            <div
              key={index}
              className="absolute bg-indigo-600 rounded-sm"
              style={{
                width: '5%',
                height: '5%',
                left: `${segment.x * 5}%`,
                top: `${segment.y * 5}%`,
              }}
            />
          ))}
          <div
            className="absolute bg-red-500 rounded-full"
            style={{
              width: '5%',
              height: '5%',
              left: `${food.x * 5}%`,
              top: `${food.y * 5}%`,
            }}
          />
        </div>
      </div>
      
      <div className="mt-4 text-center text-gray-600">
        Use arrow keys to control the snake
      </div>
    </div>
  );
};