import React from 'react';
import { Link } from 'react-router-dom';
import { Video, BookOpen, CheckSquare, GraduationCap, Calculator, BookOpenCheck, Gamepad2 } from 'lucide-react';
import { useAuthStore } from '../store/authStore';

export const Home = () => {
  const { isAdmin } = useAuthStore();

  if (isAdmin) {
    return (
      <div className="text-center">
        <h1 className="text-3xl font-bold text-gray-900 mb-8">Admin Dashboard</h1>
        <p className="text-lg text-gray-600 mb-4">Please use the admin panel to manage content.</p>
        <Link
          to="/admin"
          className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700"
        >
          Manage from here
        </Link>
      </div>
    );
  }

  const cards = [
    {
      title: 'Educational Videos',
      description: 'Watch curated educational content',
      icon: Video,
      path: '/videos',
      color: 'bg-blue-500',
    },
    {
      title: 'Notes',
      description: 'Manage your study materials',
      icon: BookOpen,
      path: '/notes',
      color: 'bg-green-500',
    },
    {
      title: 'To-Do List',
      description: 'Track your tasks and assignments',
      icon: CheckSquare,
      path: '/todos',
      color: 'bg-purple-500',
    },
    {
      title: 'Study Resources',
      description: 'Access additional learning materials',
      icon: GraduationCap,
      path: '/resources',
      color: 'bg-red-500',
    },
    {
      title: 'Calculator',
      description: 'Scientific calculator with advanced functions',
      icon: Calculator,
      path: '/calculator',
      color: 'bg-yellow-500',
    },
    {
      title: 'Formula Library',
      description: 'Comprehensive collection of formulas',
      icon: BookOpenCheck,
      path: '/formulas',
      color: 'bg-pink-500',
    },
    {
      title: 'Study Break Games',
      description: 'Take a break with educational games',
      icon: Gamepad2,
      path: '/games',
      color: 'bg-indigo-500',
    }
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">Welcome to Study Portal</h1>
        <p className="text-lg text-gray-600 max-w-2xl mx-auto">
          Your all-in-one platform for learning, organizing, and achieving academic success
        </p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {cards.map((card) => {
          const Icon = card.icon;
          return (
            <Link
              key={card.path}
              to={card.path}
              className="transform transition-all hover:scale-105 group"
            >
              <div className="bg-white rounded-xl shadow-md overflow-hidden group-hover:shadow-xl">
                <div className={`${card.color} p-6 flex justify-center group-hover:opacity-90 transition-opacity`}>
                  <Icon className="h-12 w-12 text-white" />
                </div>
                <div className="p-6">
                  <h3 className="text-lg font-semibold text-gray-900 mb-2 group-hover:text-indigo-600">
                    {card.title}
                  </h3>
                  <p className="text-gray-600">{card.description}</p>
                </div>
              </div>
            </Link>
          );
        })}
      </div>
    </div>
  );
};