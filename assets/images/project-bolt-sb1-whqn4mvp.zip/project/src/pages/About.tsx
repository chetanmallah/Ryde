import React from 'react';
import { BookOpen, Users, Award, Target } from 'lucide-react';

export const About = () => {
  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center mb-16">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">About Study Portal</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Empowering learners worldwide with high-quality educational content and
            interactive learning experiences.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
          {[
            {
              icon: BookOpen,
              title: '1000+ Courses',
              description: 'Comprehensive library of educational content across various subjects',
            },
            {
              icon: Users,
              title: '50,000+ Students',
              description: 'Growing community of active learners from around the world',
            },
            {
              icon: Award,
              title: 'Expert Instructors',
              description: 'Learn from industry professionals and experienced educators',
            },
            {
              icon: Target,
              title: 'Focused Learning',
              description: 'Structured courses designed for effective skill acquisition',
            },
          ].map((item, index) => {
            const Icon = item.icon;
            return (
              <div
                key={index}
                className="bg-white rounded-xl shadow-lg p-8 transform hover:scale-105 transition-transform duration-300"
              >
                <div className="flex items-center justify-center w-16 h-16 bg-indigo-100 rounded-full mb-6 mx-auto">
                  <Icon className="h-8 w-8 text-indigo-600" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 text-center mb-2">
                  {item.title}
                </h3>
                <p className="text-gray-600 text-center">{item.description}</p>
              </div>
            );
          })}
        </div>

        <div className="bg-white rounded-2xl shadow-xl overflow-hidden">
          <div className="grid grid-cols-1 md:grid-cols-2">
            <div className="p-8 md:p-12">
              <h2 className="text-3xl font-bold text-gray-900 mb-4">Our Mission</h2>
              <p className="text-gray-600 mb-6">
                We believe that education should be accessible to everyone. Our mission is to
                provide high-quality educational content that helps students achieve their
                learning goals through interactive video courses and comprehensive study
                materials.
              </p>
              <p className="text-gray-600">
                Whether you're a student looking to excel in your studies or a professional
                seeking to upgrade your skills, Study Portal is here to support your learning
                journey with carefully curated content and an engaging learning experience.
              </p>
            </div>
            <div className="relative h-64 md:h-auto">
              <img
                src="https://images.unsplash.com/photo-1522202176988-66273c2fd55f?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1471&q=80"
                alt="Team collaboration"
                className="absolute inset-0 w-full h-full object-cover"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};