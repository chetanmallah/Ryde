import React, { useState } from 'react';
import { Search, BookOpenCheck } from 'lucide-react';

export const Formulas = () => {
  const [searchTerm, setSearchTerm] = useState('');

  const formulas = [
    {
      category: 'Mathematics',
      items: [
        { name: 'Quadratic Formula', formula: 'x = (-b ± √(b² - 4ac)) / 2a' },
        { name: 'Pythagorean Theorem', formula: 'a² + b² = c²' },
        { name: 'Area of Circle', formula: 'A = πr²' },
        { name: 'Volume of Sphere', formula: 'V = (4/3)πr³' },
      ],
    },
    {
      category: 'Physics',
      items: [
        { name: "Newton's Second Law", formula: 'F = ma' },
        { name: 'Kinetic Energy', formula: 'KE = ½mv²' },
        { name: 'Gravitational Force', formula: 'F = G(m₁m₂)/r²' },
        { name: "Einstein's Mass-Energy", formula: 'E = mc²' },
      ],
    },
    {
      category: 'Chemistry',
      items: [
        { name: 'Density', formula: 'ρ = m/V' },
        { name: 'Ideal Gas Law', formula: 'PV = nRT' },
        { name: 'pH Scale', formula: 'pH = -log[H⁺]' },
        { name: 'Molarity', formula: 'M = moles/liters' },
      ],
    },
  ];

  const filteredFormulas = formulas.map(category => ({
    ...category,
    items: category.items.filter(item =>
      item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.formula.toLowerCase().includes(searchTerm.toLowerCase())
    ),
  })).filter(category => category.items.length > 0);

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <div className="text-center mb-8">
        <div className="flex items-center justify-center mb-4">
          <BookOpenCheck className="h-8 w-8 text-indigo-600 mr-2" />
          <h1 className="text-3xl font-bold text-gray-900">Formula Library</h1>
        </div>
        <p className="text-gray-600">Quick reference for common formulas across subjects</p>
      </div>

      <div className="relative mb-8">
        <Search className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
        <input
          type="text"
          placeholder="Search formulas..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
        />
      </div>

      <div className="space-y-8">
        {filteredFormulas.map((category) => (
          <div key={category.category}>
            <h2 className="text-xl font-semibold text-gray-900 mb-4">{category.category}</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {category.items.map((item, index) => (
                <div
                  key={index}
                  className="bg-white p-4 rounded-lg shadow-md hover:shadow-lg transition-shadow"
                >
                  <h3 className="text-lg font-medium text-gray-900 mb-2">{item.name}</h3>
                  <p className="text-lg font-mono text-indigo-600">{item.formula}</p>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};