import React from 'react';
import { useNavigate, Link, useLocation } from 'react-router-dom';
import { 
  Video, Users, Settings, LayoutDashboard, BookOpen, 
  CheckSquare, GraduationCap, ArrowLeft, BarChart3,
  Users2, FileSpreadsheet, Bell
} from 'lucide-react';

export const Admin = () => {
  const navigate = useNavigate();
  const location = useLocation();

  const adminFeatures = [
    {
      title: 'Manage Videos',
      description: 'Add, edit, or remove educational videos',
      icon: Video,
      action: () => navigate('/videos'),
      color: 'bg-blue-500',
    },
    {
      title: 'User Management',
      description: 'View and manage user accounts',
      icon: Users,
      action: () => {},
      color: 'bg-green-500',
    },
    {
      title: 'Analytics',
      description: 'View platform statistics and usage data',
      icon: BarChart3,
      action: () => {},
      color: 'bg-purple-500',
    },
    {
      title: 'Community',
      description: 'Manage user discussions and forums',
      icon: Users2,
      action: () => {},
      color: 'bg-pink-500',
    },
    {
      title: 'Reports',
      description: 'Generate and view system reports',
      icon: FileSpreadsheet,
      action: () => {},
      color: 'bg-yellow-500',
    },
    {
      title: 'Notifications',
      description: 'Manage system notifications',
      icon: Bell,
      action: () => {},
      color: 'bg-indigo-500',
    },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Admin Navigation */}
      <nav className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex items-center space-x-8">
              <Link
                to="/admin"
                className="flex items-center space-x-2 text-gray-900 hover:text-indigo-600"
              >
                <GraduationCap className="h-8 w-8" />
                <span className="text-xl font-bold">Study Portal</span>
              </Link>
              <div className="hidden md:flex items-center space-x-4">
                <Link
                  to="/admin"
                  className={`flex items-center px-3 py-2 rounded-md ${
                    location.pathname === '/admin'
                      ? 'text-indigo-600 bg-indigo-50'
                      : 'text-gray-900 hover:text-indigo-600 hover:bg-gray-50'
                  }`}
                >
                  <LayoutDashboard className="h-5 w-5 mr-2" />
                  Dashboard
                </Link>
                <Link
                  to="/videos"
                  className={`flex items-center px-3 py-2 rounded-md ${
                    location.pathname === '/videos'
                      ? 'text-indigo-600 bg-indigo-50'
                      : 'text-gray-900 hover:text-indigo-600 hover:bg-gray-50'
                  }`}
                >
                  <Video className="h-5 w-5 mr-2" />
                  Videos
                </Link>
                <Link
                  to="/notes"
                  className={`flex items-center px-3 py-2 rounded-md ${
                    location.pathname === '/notes'
                      ? 'text-indigo-600 bg-indigo-50'
                      : 'text-gray-900 hover:text-indigo-600 hover:bg-gray-50'
                  }`}
                >
                  <BookOpen className="h-5 w-5 mr-2" />
                  Notes
                </Link>
                <Link
                  to="/todos"
                  className={`flex items-center px-3 py-2 rounded-md ${
                    location.pathname === '/todos'
                      ? 'text-indigo-600 bg-indigo-50'
                      : 'text-gray-900 hover:text-indigo-600 hover:bg-gray-50'
                  }`}
                >
                  <CheckSquare className="h-5 w-5 mr-2" />
                  Tasks
                </Link>
              </div>
            </div>
          </div>
        </div>
      </nav>

      {location.pathname === '/admin' && (
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="flex items-center justify-between mb-8">
            <h1 className="text-3xl font-bold text-gray-900">Admin Dashboard</h1>
            <Link
              to="/"
              className="flex items-center text-gray-600 hover:text-indigo-600"
            >
              <ArrowLeft className="h-5 w-5 mr-2" />
              Back to Home
            </Link>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {adminFeatures.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <button
                  key={index}
                  onClick={feature.action}
                  className="bg-white p-6 rounded-xl shadow-lg hover:shadow-xl transition-all duration-200 transform hover:scale-105 border border-gray-100"
                >
                  <div className="flex items-center space-x-4">
                    <div className={`${feature.color} p-3 rounded-lg`}>
                      <Icon className="h-6 w-6 text-white" />
                    </div>
                    <div className="flex-1 min-w-0 text-left">
                      <h3 className="text-lg font-semibold text-gray-900">
                        {feature.title}
                      </h3>
                      <p className="mt-1 text-sm text-gray-500">
                        {feature.description}
                      </p>
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};