import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Video } from '../types/video';
import { VideoPlayer } from '../components/VideoPlayer';
import { VideoSkeleton } from '../components/VideoSkeleton';
import { supabase } from '../lib/supabase';
import toast from 'react-hot-toast';
import { Play } from 'lucide-react';

export const VideoDetail = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [video, setVideo] = useState<Video | null>(null);
  const [relatedCourses, setRelatedCourses] = useState<Video[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchVideo = async () => {
      if (!id) return;
      
      try {
        setLoading(true);
        const { data, error } = await supabase
          .from('videos')
          .select('*')
          .eq('id', id)
          .single();

        if (error) throw error;
        if (!data) throw new Error('Video not found');

        setVideo(data);

        // Fetch related courses from the same category
        const { data: relatedData, error: relatedError } = await supabase
          .from('videos')
          .select('*')
          .eq('category', data.category)
          .neq('id', id)
          .limit(6);

        if (relatedError) throw relatedError;
        setRelatedCourses(relatedData || []);
      } catch (error: any) {
        toast.error(error.message, {
          style: {
            background: '#FEE2E2',
            color: '#991B1B',
            border: '1px solid #F87171',
          },
          icon: '❌',
        });
      } finally {
        setLoading(false);
      }
    };

    fetchVideo();
  }, [id]);

  if (loading) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <VideoSkeleton />
      </div>
    );
  }

  if (!video) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="text-center">
          <h2 className="text-2xl font-semibold text-gray-900">Video not found</h2>
          <p className="mt-2 text-gray-600">The video you're looking for doesn't exist or has been removed.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <div className="bg-black rounded-lg overflow-hidden">
            <VideoPlayer video={video} />
          </div>
          
          <div className="mt-6">
            <h1 className="text-2xl font-bold text-gray-900">{video.title}</h1>
            <span className="mt-2 inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-indigo-100 text-indigo-800">
              {video.category}
            </span>
            
            <p className="mt-4 text-gray-600 whitespace-pre-wrap">{video.description}</p>
          </div>
        </div>

        <div className="lg:col-span-1">
          <h2 className="text-xl font-semibold mb-4">Related Courses</h2>
          <div className="space-y-4">
            {relatedCourses.map((course) => (
              <div
                key={course.id}
                className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-all duration-200 transform hover:scale-105 cursor-pointer"
                onClick={() => navigate(`/video/${course.id}`)}
              >
                <div className="aspect-video bg-gray-100 relative">
                  {course.thumbnail_url ? (
                    <img
                      src={course.thumbnail_url}
                      alt={course.title}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="absolute inset-0 flex items-center justify-center">
                      <span className="text-gray-400">No thumbnail</span>
                    </div>
                  )}
                  <div className="absolute inset-0 bg-black bg-opacity-30 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity">
                    <Play className="h-12 w-12 text-white" />
                  </div>
                </div>
                <div className="p-4">
                  <h3 className="font-medium text-gray-900 line-clamp-2">
                    {course.title}
                  </h3>
                  <p className="mt-1 text-sm text-gray-500 line-clamp-2">
                    {course.description}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};