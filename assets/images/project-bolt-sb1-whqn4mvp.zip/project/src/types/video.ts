export interface VideoCategory {
  id: string;
  name: string;
  description: string | null;
}

export interface VideoTag {
  id: string;
  name: string;
}

export interface Video {
  id: string;
  title: string;
  description: string | null;
  url: string;
  thumbnail_url: string | null;
  notes: string | null;
  category_id: string;
  duration: string | null;
  order: number;
  is_published: boolean;
  created_at: string;
  created_by: string;
  category?: VideoCategory;
  tags?: VideoTag[];
}