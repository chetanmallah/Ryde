import React from 'react';

export const VideoSkeleton: React.FC = () => {
  return (
    <div className="animate-pulse">
      <div className="aspect-w-16 aspect-h-9 bg-gray-200 rounded-lg mb-4" />
      <div className="space-y-3">
        <div className="h-6 bg-gray-200 rounded w-3/4" />
        <div className="h-4 bg-gray-200 rounded w-1/2" />
        <div className="space-y-2">
          <div className="h-4 bg-gray-200 rounded" />
          <div className="h-4 bg-gray-200 rounded w-5/6" />
          <div className="h-4 bg-gray-200 rounded w-4/6" />
        </div>
      </div>
    </div>
  );
};