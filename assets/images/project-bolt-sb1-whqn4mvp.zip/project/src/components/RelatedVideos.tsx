import React from 'react';
import { Link } from 'react-router-dom';
import { Video } from '../types/video';

interface RelatedVideosProps {
  videos: Video[];
  currentVideoId: string;
}

export const RelatedVideos: React.FC<RelatedVideosProps> = ({ videos, currentVideoId }) => {
  const filteredVideos = videos.filter(video => video.id !== currentVideoId);

  if (filteredVideos.length === 0) {
    return null;
  }

  return (
    <div className="mt-8">
      <h2 className="text-xl font-semibold mb-4">Related Videos</h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredVideos.map(video => (
          <Link
            key={video.id}
            to={`/videos/${video.id}`}
            className="group block"
          >
            <div className="aspect-w-16 aspect-h-9 bg-gray-100 rounded-lg overflow-hidden mb-2">
              {video.thumbnail_url ? (
                <img
                  src={video.thumbnail_url}
                  alt={video.title}
                  className="object-cover w-full h-full group-hover:scale-105 transition-transform duration-200"
                />
              ) : (
                <div className="w-full h-full bg-gray-200 flex items-center justify-center">
                  <span className="text-gray-400">No thumbnail</span>
                </div>
              )}
            </div>
            <h3 className="font-medium text-gray-900 group-hover:text-indigo-600 transition-colors">
              {video.title}
            </h3>
            {video.duration && (
              <span className="text-sm text-gray-500">{video.duration}</span>
            )}
          </Link>
        ))}
      </div>
    </div>
  );
};