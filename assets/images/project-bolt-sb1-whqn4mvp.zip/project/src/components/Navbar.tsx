import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { LogOut, BookOpen, Video, CheckSquare, GraduationCap } from 'lucide-react';
import { useAuthStore } from '../store/authStore';
import { supabase } from '../lib/supabase';
import toast from 'react-hot-toast';
import { Dialog } from './Dialog';

export const Navbar = () => {
  const { user, isAdmin, setUser, setIsAdmin } = useAuthStore();
  const navigate = useNavigate();
  const [showLogoutDialog, setShowLogoutDialog] = useState(false);

  const handleLogout = async () => {
    try {
      await supabase.auth.signOut();
      setUser(null);
      setIsAdmin(false);
      toast.success('Logged out successfully', {
        style: {
          background: '#10B981',
          color: '#FFFFFF',
          borderRadius: '10px',
          padding: '16px',
        },
        icon: '👋',
        duration: 3000,
      });
      navigate('/login');
    } catch (error) {
      toast.error('Failed to log out. Please try again.', {
        style: {
          background: '#EF4444',
          color: '#FFFFFF',
          borderRadius: '10px',
          padding: '16px',
        },
        icon: '❌',
        duration: 3000,
      });
    }
    setShowLogoutDialog(false);
  };

  return (
    <>
      <nav className="bg-indigo-600 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center">
              <Link to="/" className="flex items-center space-x-2">
                <GraduationCap className="h-8 w-8" />
                <span className="text-xl font-bold">Study Portal</span>
              </Link>
            </div>

            {user && (
              <div className="flex items-center space-x-4">
                {!isAdmin && (
                  <>
                    <Link to="/videos" className="flex items-center space-x-1 hover:text-indigo-200">
                      <Video className="h-5 w-5" />
                      <span>Videos</span>
                    </Link>
                    <Link to="/notes" className="flex items-center space-x-1 hover:text-indigo-200">
                      <BookOpen className="h-5 w-5" />
                      <span>Notes</span>
                    </Link>
                    <Link to="/todos" className="flex items-center space-x-1 hover:text-indigo-200">
                      <CheckSquare className="h-5 w-5" />
                      <span>To-Do</span>
                    </Link>
                  </>
                )}
                <button
                  onClick={() => setShowLogoutDialog(true)}
                  className="flex items-center space-x-1 px-3 py-2 rounded-md bg-indigo-700 hover:bg-indigo-800"
                >
                  <LogOut className="h-5 w-5" />
                  <span>Logout</span>
                </button>
              </div>
            )}
          </div>
        </div>
      </nav>

      <Dialog
        isOpen={showLogoutDialog}
        onClose={() => setShowLogoutDialog(false)}
        title="Confirm Logout"
      >
        <div className="mt-2">
          <p className="text-gray-600">Are you sure you want to log out? You'll need to sign in again to access your account.</p>
        </div>
        <div className="mt-6 flex justify-end space-x-3">
          <button
            type="button"
            className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50"
            onClick={() => setShowLogoutDialog(false)}
          >
            Cancel
          </button>
          <button
            type="button"
            className="px-4 py-2 text-sm font-medium text-white bg-red-600 rounded-md hover:bg-red-700"
            onClick={handleLogout}
          >
            Logout
          </button>
        </div>
      </Dialog>
    </>
  );
};