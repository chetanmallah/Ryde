import React, { useEffect, useRef, useState } from 'react';
import { Video } from '../types/video';
import toast from 'react-hot-toast';

interface VideoPlayerProps {
  video: Video;
}

export const VideoPlayer: React.FC<VideoPlayerProps> = ({ video }) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const loadSavedProgress = () => {
      try {
        const savedProgress = localStorage.getItem(`video-progress-${video.id}`);
        if (savedProgress && videoRef.current) {
          videoRef.current.currentTime = parseFloat(savedProgress);
        }
      } catch (err) {
        console.error('Error loading video progress:', err);
      }
    };

    // Save progress every 2 seconds while playing
    let saveInterval: NodeJS.Timeout;
    const startSavingProgress = () => {
      saveInterval = setInterval(() => {
        if (videoRef.current && !videoRef.current.paused) {
          try {
            localStorage.setItem(
              `video-progress-${video.id}`,
              videoRef.current.currentTime.toString()
            );
          } catch (err) {
            console.error('Error saving video progress:', err);
          }
        }
      }, 2000);
    };

    loadSavedProgress();
    startSavingProgress();

    return () => {
      if (saveInterval) {
        clearInterval(saveInterval);
      }
    };
  }, [video.id]);

  const handleVideoError = () => {
    setError('Failed to load video. Please try again later.');
    toast.error('Error loading video', {
      style: {
        background: '#FEE2E2',
        color: '#991B1B',
        border: '1px solid #F87171',
      },
      icon: '❌',
    });
  };

  const handleVideoLoaded = () => {
    setIsLoading(false);
    setError(null);
    toast.success('Video loaded successfully', {
      style: {
        background: '#ECFDF5',
        color: '#065F46',
        border: '1px solid #34D399',
      },
      icon: '✅',
    });
  };

  return (
    <div className="relative aspect-w-16 aspect-h-9 bg-black rounded-lg overflow-hidden">
      {isLoading && !error && (
        <div className="absolute inset-0 flex items-center justify-center bg-gray-900">
          <div className="animate-spin rounded-full h-12 w-12 border-4 border-indigo-500 border-t-transparent"></div>
        </div>
      )}
      
      {error && (
        <div className="absolute inset-0 flex items-center justify-center bg-gray-900">
          <div className="text-white text-center px-4">
            <p className="mb-4">{error}</p>
            <button
              onClick={() => window.location.reload()}
              className="px-4 py-2 bg-indigo-600 rounded-lg hover:bg-indigo-700 transition-colors"
            >
              Retry
            </button>
          </div>
        </div>
      )}

      <video
        ref={videoRef}
        src={video.url}
        controls
        className="w-full h-full object-contain"
        poster={video.thumbnail_url || undefined}
        onLoadedData={handleVideoLoaded}
        onError={handleVideoError}
        playsInline
      >
        Your browser does not support the video tag.
      </video>
    </div>
  );
};