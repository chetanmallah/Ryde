/*
  # Enhance Videos Schema

  1. New Tables
    - `video_categories`
      - `id` (uuid, primary key)
      - `name` (text, unique)
      - `description` (text)
      - `created_at` (timestamp)
    
    - `video_tags`
      - `id` (uuid, primary key)
      - `name` (text, unique)
      - `created_at` (timestamp)
    
    - `video_tag_relations`
      - `video_id` (uuid, foreign key)
      - `tag_id` (uuid, foreign key)

  2. Updates to Videos Table
    - Add `thumbnail_url` column
    - Add `notes` column for accompanying text
    - Add `category_id` foreign key
    - Add `duration` column
    - Add `order` column for sequence

  3. Security
    - Enable RLS on all tables
    - Add policies for admin and user access
*/

-- Create video categories table
CREATE TABLE video_categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text UNIQUE NOT NULL,
  description text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE video_categories ENABLE ROW LEVEL SECURITY;

-- Create video tags table
CREATE TABLE video_tags (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text UNIQUE NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE video_tags ENABLE ROW LEVEL SECURITY;

-- Create video tag relations table
CREATE TABLE video_tag_relations (
  video_id uuid REFERENCES videos(id) ON DELETE CASCADE,
  tag_id uuid REFERENCES video_tags(id) ON DELETE CASCADE,
  PRIMARY KEY (video_id, tag_id)
);

ALTER TABLE video_tag_relations ENABLE ROW LEVEL SECURITY;

-- Add new columns to videos table
ALTER TABLE videos 
  ADD COLUMN thumbnail_url text,
  ADD COLUMN notes text,
  ADD COLUMN category_id uuid REFERENCES video_categories(id),
  ADD COLUMN duration interval,
  ADD COLUMN "order" integer DEFAULT 0,
  ADD COLUMN is_published boolean DEFAULT false;

-- Categories policies
CREATE POLICY "Everyone can view categories"
  ON video_categories
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Only admins can modify categories"
  ON video_categories
  FOR ALL
  TO authenticated
  USING (auth.jwt() ->> 'email' = 'admin@gmail.com')
  WITH CHECK (auth.jwt() ->> 'email' = 'admin@gmail.com');

-- Tags policies
CREATE POLICY "Everyone can view tags"
  ON video_tags
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Only admins can modify tags"
  ON video_tags
  FOR ALL
  TO authenticated
  USING (auth.jwt() ->> 'email' = 'admin@gmail.com')
  WITH CHECK (auth.jwt() ->> 'email' = 'admin@gmail.com');

-- Tag relations policies
CREATE POLICY "Everyone can view tag relations"
  ON video_tag_relations
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Only admins can modify tag relations"
  ON video_tag_relations
  FOR ALL
  TO authenticated
  USING (auth.jwt() ->> 'email' = 'admin@gmail.com')
  WITH CHECK (auth.jwt() ->> 'email' = 'admin@gmail.com');

-- Create helper functions
CREATE OR REPLACE FUNCTION get_related_videos(video_id uuid, limit_count integer DEFAULT 5)
RETURNS SETOF videos AS $$
BEGIN
  RETURN QUERY
  SELECT DISTINCT v.*
  FROM videos v
  JOIN video_tag_relations vtr1 ON v.id = vtr1.video_id
  JOIN video_tag_relations vtr2 ON vtr1.tag_id = vtr2.tag_id
  WHERE vtr2.video_id = video_id
    AND v.id != video_id
    AND v.is_published = true
  LIMIT limit_count;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;